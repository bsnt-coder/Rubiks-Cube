//
// Created by Lakshya Mittal on 01-02-2022.
//

#ifndef RUBIKS_CUBE_SOLVER_PATTERNDATABASE_H
#define RUBIKS_CUBE_SOLVER_PATTERNDATABASE_H

template<typename T>
class PatternDatabaseEstimate {
private:

public:
    int getEstimate(T rubiksCube) {
        return 0;
    }

};

#endif //RUBIKS_CUBE_SOLVER_PATTERNDATABASE_H
